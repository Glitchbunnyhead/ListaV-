package persistencia;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import model.Endereco;
import model.Usuario;

public class EnderecoDAO {
    private ConexaoMysql conexao;

    public EnderecoDAO(){
        conexao = new ConexaoMysql();
    }

    public void salvar(Endereco endereco){
        try{
            conexao.abrirConexao();
            String sql = "INSERT INTO endereco VALUES(NULL,?,?,?,?,?;)";
            PreparedStatement st = conexao.getConexao().prepareStatement(sql);
			st.setString(1, endereco.getRua());
			st.setInt(2, endereco.getNumero());
			st.setString(3, endereco.getCidade());
            st.setString(4, endereco.getEstado());
            st.setLong(5,endereco.getUsuario().getId());
			st.executeUpdate();
        }
        catch(SQLException e){
            e.printStackTrace();
        }

        finally{
            conexao.fecharConexao();
        }
    }

    public void editar(Endereco endereco){
        try{
            conexao.abrirConexao();
            String sql = "UPTADE endereco SET rua = ?, numero = ?, cidade = ?, estado = ?, id_usuario = ? WHERE id_endereco = ?;";
            PreparedStatement st = conexao.getConexao().prepareStatement(sql);
			st.setString(1, endereco.getRua());
			st.setInt(2, endereco.getNumero());
			st.setString(3, endereco.getCidade());
            st.setString(4, endereco.getEstado());
            st.setLong(5,endereco.getUsuario().getId());
            st.setLong(6,endereco.getId());
			st.executeUpdate();

        }
        catch(SQLException e){
            e.printStackTrace();
        }

        finally{
            conexao.fecharConexao();
        }
    }

    public void excluir(Endereco endereco){
        try{
            conexao.abrirConexao();
            String sql = "DELETE FROM endereco WHERE id_endereco = ?;";
            PreparedStatement st = conexao.getConexao().prepareStatement(sql);
            st.setLong(1,endereco.getId());
            st.executeUpdate();

        }
        catch(SQLException e){
            e.printStackTrace();
        }
        finally{
            conexao.fecharConexao();
        }
    }

    public Endereco buscar(long id){
        Endereco endereco = null;

        try{
            conexao.abrirConexao();
            String sql = "SELECT * FROM endereco WHERE id_endereco = ?;";
            PreparedStatement st = conexao.getConexao().prepareStatement(sql);
            st.setLong(1, id);
            ResultSet rs = st.executeQuery();
            if(rs.next()){
                UsuarioDAO usuarioDAO = new UsuarioDAO();
                Usuario usuario = usuarioDAO.buscar(rs.getLong("id_usuario"));
                endereco = new Endereco(id, rs.getString("rua"), rs.getInt("numero"),rs.getString("cidade"), rs.getString("estado"),usuario);
            }

        }
        catch(SQLException e){
            e.printStackTrace();
        }
        finally{
            conexao.fecharConexao();
        }
        return endereco;
    }

    public List<Endereco> buscarTodos(){
        List<Endereco> lista = new ArrayList<>();
        try{

            conexao.abrirConexao();
            String sql = "SELECT * FROM endereco;";
            PreparedStatement st = conexao.getConexao().prepareStatement(sql);
			ResultSet rs = st.executeQuery();
			while(rs.next()){
                UsuarioDAO usuarioDAO = new UsuarioDAO();
                Usuario usuario = usuarioDAO.buscar(rs.getLong("id_usuario"));
                Endereco endereco = new Endereco(rs.getLong("id_endereco"), rs.getString("rua"), rs.getInt("numero"),rs.getString("cidade"), rs.getString("estado"),usuario);
                lista.add(endereco);

            }
        }
        catch(SQLException e){
            e.printStackTrace();
        }
        finally{
            conexao.fecharConexao();
        }
        return lista;
    }

    
}
