package persistencia;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.naming.spi.DirStateFactory.Result;

import model.Usuario;

public class UsuarioDAO {
	private ConexaoMysql conexao;

	public UsuarioDAO() {
		conexao = new ConexaoMysql();
	}

	// salvar
	public void salvar(Usuario usuario) {
		// abrir a conexao
		conexao.abrirConexao();
		// montar um String de insert
		String sql = "INSERT INTO usuario VALUES(null, ?, ?, ?);";
		// preparar o sql para ser executado (substituir as ? pelos valores)
		try {
			PreparedStatement st = conexao.getConexao().prepareStatement(sql);
			st.setString(1, usuario.getNome());
			st.setString(2, usuario.getEmail());
			st.setString(3, usuario.getSenha());
			// executar o insert
			st.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			// fechar a conexao
			conexao.fecharConexao();
		}
	}

	// editar
	public void editar(Usuario usuario) {
		// abrir a conexao
		conexao.abrirConexao();
		// montar um String de update
		String sql = "UPDATE usuario SET nome=?, email=?, senha=? WHERE id_usuario=?;";
		// preparar o sql para ser executado (substituir as ? pelos valores)
		try {
			PreparedStatement st = conexao.getConexao().prepareStatement(sql);
			st.setString(1, usuario.getNome());
			st.setString(2, usuario.getEmail());
			st.setString(3, usuario.getSenha());
			st.setLong(4, usuario.getId());
			// executar o update
			st.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			// fechar a conexao
			conexao.fecharConexao();
		}
	}
	// excluirPorId
	// excluirTodos
	public Usuario buscar(long id){
		Usuario a = null;
		try{
			conexao.abrirConexao();
			String sql = "SELECT * FROM usuario WHERE id_usuario = ?;";
			PreparedStatement st = conexao.getConexao().prepareStatement(sql);
			st.setLong(1, id);
			ResultSet rs = st.executeQuery();
			if(rs.next()){
				a = new Usuario(id,rs.getString("nome"), rs.getString("email"),rs.getString("senha"));
			}
			
		}
		catch(SQLException e){
			e.printStackTrace();
		}
		finally{
			conexao.fecharConexao();
		}
		return a;

	}
	
	public List<Usuario> buscarTodos(){
		List<Usuario> lista = new ArrayList<>();
		try{
			conexao.abrirConexao();
			String sql = "SELECT * FROM usuario;";
			PreparedStatement st = conexao.getConexao().prepareStatement(sql);
			ResultSet rs = st.executeQuery();
			while(rs.next()){
				Usuario usuario = new Usuario(rs.getLong("id_usuario"),rs.getString("nome"), rs.getString("email"),rs.getString("senha"));
				lista.add(usuario);
			}
			
		}
		catch(SQLException e){
			e.printStackTrace();

		}
		finally{
			conexao.fecharConexao();
		}
		return lista;

	}
}
