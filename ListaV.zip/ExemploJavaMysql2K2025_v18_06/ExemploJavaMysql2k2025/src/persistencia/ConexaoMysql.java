package persistencia;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConexaoMysql {
	private final String IP = "localhost";
	private final String PORTA = "3306";
	private final String LOGIN = "root";
	private final String SENHA = "root";
	private final String NOME_BD = "bd_java_mysql_2k_2025";

	private Connection conexao;

	public Connection getConexao() {
		return conexao;
	}
	
	// abrir conexao
	public void abrirConexao() {
		String url = "jdbc:mysql://" + IP + ":" + PORTA + "/" + NOME_BD;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			conexao = DriverManager.getConnection(url, LOGIN, SENHA);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

	// fechar conexao
	public void fecharConexao() {
		try {
			if (conexao != null && !conexao.isClosed()) {
				conexao.close();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

}
