package apresentacao;
import java.util.ArrayList;
import java.util.List;

import model.*;
import persistencia.*;


public class Teste {

	public static void main(String[] args) {

	
		Usuario u = new Usuario(4, "Cristian Remor", "cris.remor@gmail.com", "465756");
		UsuarioDAO uDAO = new UsuarioDAO();
		uDAO.editar(u);
		
		EnderecoDAO enderecoDAO = new EnderecoDAO();
		Endereco a = new Endereco(1,"rua independencia", 8, "São Leo", "RS",u);

		enderecoDAO.salvar(a);
		enderecoDAO.editar(a);
		System.out.println(enderecoDAO.buscar(1).getRua());

		ArrayList <Endereco> b = (ArrayList<Endereco>) enderecoDAO.buscarTodos();
		for(int i = 0 ; i < b.size(); i ++){
			System.out.println(b);
		}
				enderecoDAO.excluir(a);
	}

}
